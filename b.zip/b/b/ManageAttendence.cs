﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace b
{
    public partial class ManageAttendence : Form
    {

        public ManageAttendence()
        {
            InitializeComponent();

        }
        private void ManageAttendence_Load(object sender, EventArgs e)
        {

            RefreshDataGridView();
            SetupDataGridView();

            // PopulateDataGridView();
        }

        private void SetupDataGridView()
        {
            // Create a new DataGridViewComboBoxColumn
            DataGridViewComboBoxColumn comboBoxColumn = new DataGridViewComboBoxColumn();
            comboBoxColumn.HeaderText = "Attendance Status";
            comboBoxColumn.Name = "cmbAttendanceStatus";
            comboBoxColumn.Items.AddRange("Present", "Absent", "Late", "Leave");

            // Add the ComboBox column to the DataGridView
            dataGridView1.Columns.Add(comboBoxColumn);
        }
        private void RefreshDataGridView()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT TOP 1 RegistrationNumber FROM Student WHERE Status = 5", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void RefreshDataGridView2()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT RegistrationNumber FROM Student WHERE Status  = 5", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        //private int GetStatusId(string statusName)
        //{
        //    SqlConnection con = null;
        //    int statusId = -1; // Default value if status is not found
        //    using (con = Configuration.getInstance().getConnection())
        //    {
        //       // if (con.State == ConnectionState.Closed)
        //       // {
        //            con.Open();
        //       // }

        //        // Open the connection before executing the command
        //        using (SqlCommand cmd = new SqlCommand("SELECT LookupId FROM Lookup WHERE Name = @Name", con))
        //        {
        //            cmd.Parameters.AddWithValue("@Name", statusName);
        //            object result = cmd.ExecuteScalar();
        //            if (result != null && result != DBNull.Value)
        //            {
        //                statusId = (int)result;
        //            }
        //        }
        //    } // Connection is automatically closed here
        //    return statusId;
        //}


        private int GetStatusId2(string statusName)
        {
            int statusId = -1; // Default value if status is not found
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT LookupId FROM Lookup WHERE Name = @Name AND Category = 'ATTENDANCE_STATUS'", con);
            cmd.Parameters.AddWithValue("@Name", statusName);
            object result = cmd.ExecuteScalar();
            if (result != null && result != DBNull.Value)
            {
                statusId = (int)result;
            }
            return statusId;
        }
        private int GetStudentId(string registrationNumber)
        {
            int studentId = -1; // Default value if student is not found
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT StudentId FROM Student WHERE RegistrationNumber = @RegistrationNumber", con);
            cmd.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);
            object result = cmd.ExecuteScalar();
            if (result != null && result != DBNull.Value)
            {
                studentId = (int)result;
            }
            return studentId;
        }

        private int GetStatusId(string statusName)
        {
            int statusId = -1; // Default value if status is not found
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT LookupId FROM Lookup WHERE Name = @Name AND Category = 'ATTENDANCE_STATUS'", con);
            cmd.Parameters.AddWithValue("@Name", statusName);
            object result = cmd.ExecuteScalar();
            if (result != null && result != DBNull.Value)
            {
                statusId = (int)result;
            }
            return statusId;
        }

        ////private int GetStudentId(string registrationNumber)
        ////{
        ////    int studentId = -1; // Default value if student is not found
        ////    using (var con = Configuration.getInstance().getConnection())
        ////    {
        ////        if (con.State == ConnectionState.Closed)
        ////        {
        ////            con.Open();
        ////        }

        ////        using (SqlCommand cmd = new SqlCommand("SELECT Id FROM Student WHERE RegistrationNumber = @RegistrationNumber", con))
        ////        {
        ////            cmd.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);
        ////            object result = cmd.ExecuteScalar();
        ////            if (result != null && result != DBNull.Value)
        ////            {
        ////                studentId = (int)result;
        ////            }
        ////        }
        ////    }
        ////    return studentId;
        ////}


        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Columns.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                // Retrieve registration number
                string registrationNumber = selectedRow.Cells["RegistrationNumber"].Value?.ToString();
                if (string.IsNullOrEmpty(registrationNumber))
                {
                    MessageBox.Show("Registration number not found in the selected row.");
                    return;
                }

                // Retrieve attendance status
                string selectedStatus = selectedRow.Cells["cmbAttendanceStatus"].Value?.ToString();
                if (string.IsNullOrEmpty(selectedStatus))
                {
                    MessageBox.Show("Attendance status not found in the selected row.");
                    return;
                }

                // Fetch the lookup ID for the selected attendance status
                int statusId = GetStatusId(selectedStatus);
                if (statusId == -1)
                {
                    MessageBox.Show($"Status '{selectedStatus}' not found in the Lookup table.");
                    return;
                }

                // Get the student ID based on the registration number
                int studentId = GetStudentId(registrationNumber);
                if (studentId == -1)
                {
                    MessageBox.Show($"Student with registration number '{registrationNumber}' not found.");
                    return;
                }

                // Save attendance record
                InsertAttendanceRecord(studentId, statusId);
                MessageBox.Show("Attendance saved successfully.");
            }
            else
            {
                MessageBox.Show("Please select a student.");
            }
        }
        private void InsertAttendanceRecord(int studentId, int attendanceStatusId)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("INSERT INTO StudentAttendance (StudentId, AttendanceStatus) VALUES (@StudentId, @AttendanceStatus)", con);
            cmd.Parameters.AddWithValue("@StudentId", studentId);
            cmd.Parameters.AddWithValue("@AttendanceStatus", attendanceStatusId);
            cmd.ExecuteNonQuery();
        }
        //private void InsertAttendanceRecord(int studentId, int attendanceStatusId)
        //{
        //    SqlConnection con = null;
        //    try
        //    {
        //        con = Configuration.getInstance().getConnection();
        //        con.Open(); // Ensure the connection is open before executing the command
        //        SqlCommand cmd = new SqlCommand("INSERT INTO StudentAttendance (StudentId,AttendanceStatus) VALUES (@StudentId, @AttendanceStatus)", con);
        //        cmd.Parameters.AddWithValue("@StudentId", studentId);
        //        cmd.Parameters.AddWithValue("@AttendanceStatus", attendanceStatusId);
        //        cmd.ExecuteNonQuery();
        //    }
        //    //catch (Exception ex)
        //    {
        //        // Handle any exceptions, e.g., display error message or log the exception
        //        MessageBox.Show("Error inserting attendance record: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }
        //    finally
        //    {
        //        // Close the connection
        //       // con.Close();
        //    }
        //}

    }
}